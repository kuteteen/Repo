This is an example of a LockGlyph theme.

IdleImage.png, IdleImage@2x.png and IdleImage@3x.png are the images that appears when a fingerprint is not being scanned.
This replaces the default fingerprint glyph.

SuccessSound.wav is the sound that plays when a fingerprint has successfully been scanned.
This replaces the default Apple Pay payment sound.